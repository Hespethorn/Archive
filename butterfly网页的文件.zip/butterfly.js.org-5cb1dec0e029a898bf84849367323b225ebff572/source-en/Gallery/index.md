---
title: Gallery
comments: false
date: 2023-07-01 19:46:20
reward:
description: gallery demo
top_img: https://jsd.012700.xyz/gh/jerryc127/CDN/Photo/photo.jpg
---

{% galleryGroup 'Wallpapers' 'A collection of some wallpapers' '/Gallery/wallpaper' https://i.loli.net/2019/11/10/T7Mu8Aod3egmC4Q.png %}

{% galleryGroup 'Marvel' 'Images related to Marvel' '/Gallery/marvel' https://i.loli.net/2019/12/25/8t97aVlp4hgyBGu.jpg %}

{% galleryGroup 'OH MY GIRL' 'Images related to OH MY GIRL' '/Gallery/ohmygirl' https://i.loli.net/2019/12/25/hOqbQ3BIwa6KWpo.jpg %}
