---
title: When Setting top_img to false
tags:
  - top_img
  - butterfly
categories: Demo
keywords: 'hexo, butterfly, theme, doc, tutorial, documentation, Demo'
description: When setting top_img to false
top_img: false
cover: https://jsd.012700.xyz/gh/jerryc127/CDN/img/when-set-the-top-img-to-false.png
abbrlink: c9711c19
date: 2020-10-28 14:15:34
comments: false
---

When the top_img is set to false, the top image is not displayed.