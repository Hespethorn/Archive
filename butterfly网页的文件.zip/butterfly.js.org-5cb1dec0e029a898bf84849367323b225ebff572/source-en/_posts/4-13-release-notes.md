---
title: Butterfly 4.13 Release Notes
comments: false
date: 2024-02-22 16:54:12
tags:
  - en
  - docs
  - hexo
categories: Release Notes
keywords: 'hexo,butterfly,更新日誌,Release Notes,changelog,released,主題,doc,教程,文件'
description:
top_img:
cover: https://oss.012700.xyz/butterfly/2024/02/4-13-release-notes.png
abbrlink: 4-13-release-notes
---

## Feature
1. Adapted to waline v3.
2. Adapted to the new version of artalk.

## Fixes
1. Fixed a bug where twikoo couldn't retrieve the comment count on the article page.

## Improvements
1. Added identifiers to each tag and category on the homepage when there are multiple.
2. Changed the position of the article page title to the left.
