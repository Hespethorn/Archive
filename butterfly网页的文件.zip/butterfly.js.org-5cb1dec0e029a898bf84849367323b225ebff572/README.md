## butterfly.js.org

這是 hexo 主題 Butterfly 的文件/ Demo 倉庫

歡迎 PR 完善文件
### 提交網站到 `示例`

1. 確保你使用 Butterfly 主題 （魔改太多的可能不會合並）
2. 點擊這個[鏈接](https://github.com/jerryc127/butterfly.js.org/edit/main/source/_data/link.yml)
3. 按要求新增內容(請添加在**末尾**)
  ```yaml
    - name: 博客名
      link: 博客地址
      avatar: 博客頭像
      descr: 博客描述
  ```
4. 點擊下面的 `Commit changes` ，合併到 butterfly.js.org 倉庫