---
title: 示例
date: 2018-06-07 22:17:49
type: "link"
top_img: https://oss.012700.xyz/butterfly/2024/09/friends.jpg
comments: false
---

***

定時清理一些無法訪問的鏈接，如果你的鏈接被清理了，你可以重新提交。

如果你想把自己的網頁也新增到`示例`頁面，請


>1. 確保你使用 Butterfly 主題 （魔改太多的可能不會合並）
>2. 點擊這個[鏈接](https://github.com/jerryc127/butterfly.js.org/edit/main/source/_data/link.yml)
>3. 按要求新增內容
>4. 點擊下面的 `Commit changes` ，合併到 butterfly.js.org 倉庫

