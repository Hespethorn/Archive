---
title: 當設置 top_img 為 false 時
tags:
  - top_img
  - butterfly
categories: Demo
keywords: 'hexo,butterfly,主題,doc,教程,文檔,Demo'
description: 設置 top_img 為 false 時
top_img: false
cover: https://oss.012700.xyz/butterfly/2024/09/when-set-the-top-img-to-false.png
abbrlink: c9711c19
date: 2020-10-28 14:15:34
comments: false
---

當設置 top_img 為 false 時，不顯示頂部圖